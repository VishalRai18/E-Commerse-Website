const sproduct = [{
        id: 0,
        image: "../images/sp1.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500",
        price1: "Rupees 500",
    },
    {
        id: 1,
        image: "../images/sp2.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 2,
        image: "../images/sp3.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 3,
        image: "../images/sp4.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 4,
        image: "../images/sp5.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 5,
        image: "../images/sp6.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 6,
        image: "../images/sp7.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 7,
        image: "../images/sp8.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
];

const cproduct = [{
        id: 0,
        image: "../images/cp1.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 1,
        image: "../images/cp2.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 2,
        image: "../images/cp3.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 3,
        image: "../images/cp4.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 4,
        image: "../images/cp5.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 5,
        image: "../images/cp6.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 6,
        image: "../images/cp7.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 7,
        image: "../images/cp1.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
];

const wproduct = [{
        id: 0,
        image: "../images/wp1.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 1,
        image: "../images/wp2.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 2,
        image: "../images/wp3.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 3,
        image: "../images/wp4.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 4,
        image: "../images/wp5.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 5,
        image: "../images/wp6.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 6,
        image: "../images/wp7.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 7,
        image: "../images/wp8.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
];

const aproduct = [{
        id: 0,
        image: "../images/ap1.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 1,
        image: "../images/ap2.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 2,
        image: "../images/ap3.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 3,
        image: "../images/ap4.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 4,
        image: "../images/ap5.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 5,
        image: "../images/ap6.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 6,
        image: "../images/ap7.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
    {
        id: 7,
        image: "../images/ap8.webp",
        p: "ONE PLUS NORD ORIGINAL Price: 500.",
        price1: "Rupees 500",
    },
];

const shopProduct = document.querySelector("#zero");
const cyberProduct = document.querySelector("#first");
const wonderProduct = document.querySelector("#second");
const animeProduct = document.querySelector("#third");

function buys(id) {
    console.log(id);
    const item = sproduct.find((prod) => prod.id === id);
    console.log(item);
    localStorage.setItem("prodet", JSON.stringify(item));
    alert("Item added to cart");
}

function buyc(id) {
    console.log(id);
    const item = cproduct.find((prod) => prod.id === id);
    console.log(item);
    localStorage.setItem("prodet", JSON.stringify(item));
    alert("Item added to cart");
}

function buyw(id) {
    console.log(id);
    const item = wproduct.find((prod) => prod.id === id);
    console.log(item);
    localStorage.setItem("prodet", JSON.stringify(item));
    alert("Item added to cart");
}

function buya(id) {
    console.log(id);
    const item = aproduct.find((prod) => prod.id === id);
    console.log(item);
    localStorage.setItem("prodet", JSON.stringify(item));
    alert("Item added to cart");
}

function srenderProducts(element, product) {
    product.forEach((item) => {
        element.innerHTML += `
        <div class="content">
        <img src=${item.image} alt="">
        <p>${item.p}</p>
        <h6>${item.price1}</h6>
        <h6>${item.price2}</h6>
        <button class="buy_button"><a href="#" onclick="buys(${item.id})">ADD TO CART</a></button>
        </div>
        `;
    });
}

function arenderProducts(element, product) {
    product.forEach((item) => {
        element.innerHTML += `
        <div class="content">
        <img src=${item.image} alt="">
        <p>${item.p}</p>
        <h6>${item.price1}</h6>
        <h6>${item.price2}</h6>
        <button class="buy_button"><a href="#" onclick="buya(${item.id})">ADD TO CART</a></button>
        </div>
        `;
    });
}

function crenderProducts(element, product) {
    product.forEach((item) => {
        element.innerHTML += `
        <div class="content">
        <img src=${item.image} alt="">
        <p>${item.p}</p>
        <h6>${item.price1}</h6>
        <h6>${item.price2}</h6>
        <button class="buy_button"><a href="#" onclick="buyc(${item.id})">ADD TO CART</a></button>
        </div>
        `;
    });
}

function wrenderProducts(element, product) {
    product.forEach((item) => {
        element.innerHTML += `
        <div class="content">
        <img src=${item.image} alt="">
        <p>${item.p}</p>
        <h6>${item.price1}</h6>
        <h6>${item.price2}</h6>
        <button class="buy_button"><a href="#" onclick="buyw(${item.id})">ADD TO CART</a></button>
        </div>
        `;
    });
}
srenderProducts(shopProduct, sproduct);
crenderProducts(cyberProduct, cproduct);
wrenderProducts(wonderProduct, wproduct);
arenderProducts(animeProduct, aproduct);